SURVEILLANCE_LOOP_MONITOR

Flags repeat detections of previously observed devices, indicating potential loops or returns.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
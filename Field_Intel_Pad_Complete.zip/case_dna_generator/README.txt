CASE_DNA_GENERATOR

Generates SHA256 hashes for files to create a digital fingerprint of each case.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
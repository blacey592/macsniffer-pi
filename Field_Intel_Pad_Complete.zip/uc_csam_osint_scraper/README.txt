UC_CSAM_OSINT_SCRAPER

Offline UC profile keyword scraper that scans text files for CSAM-related terms.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
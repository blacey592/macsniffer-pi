TIMELINE_SYNTHESIZER

Merges logs into a unified, chronologically sorted timeline from MAC, Bluetooth, USB data.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
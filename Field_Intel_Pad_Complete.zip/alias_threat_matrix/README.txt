ALIAS_THREAT_MATRIX

Correlates known device aliases with log entries, identifying frequent or suspicious activity.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
INTEL_PULSE

Analyzes recent log activity and assigns a heat level (green/yellow/red) based on volume.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
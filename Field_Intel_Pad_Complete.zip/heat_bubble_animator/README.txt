HEAT_BUBBLE_ANIMATOR

Creates a basic heatmap based on RSSI and hit frequency from MAC/Bluetooth logs.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.
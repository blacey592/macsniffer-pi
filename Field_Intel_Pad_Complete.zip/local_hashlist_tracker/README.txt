LOCAL_HASHLIST_TRACKER

Tracks and manages SHA256 hashes of files, flagging duplicates across investigations.

Usage: Run with Python 3.
Each module is designed to operate standalone with default folders.